package Shapes;

/**
 * ShapeInterface
 */
public interface ShapeInterface {
    public double getArea();

    public double getPerimeter();

    public double getVolume();

}